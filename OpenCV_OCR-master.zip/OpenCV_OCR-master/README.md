# OpenCV字符OCR

### 使用OpenCV的SVM进行字符识别
1. img_data里的是原始图片，执行python main.py会对起进行识别
2. 训练请进入train文件夹看Readme.md文件
3. 产生训练图片也可以用main.py进行分割处理等，见里面的注释


